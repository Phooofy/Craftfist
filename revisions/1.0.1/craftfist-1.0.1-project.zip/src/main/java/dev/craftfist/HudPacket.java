package dev.craftfist;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
public record HudPacket(String lines) implements CustomPayload {
 public static final Id<HudPacket> ID=new Id<>(Identifier.of("craftfist","hud"));
 public static final PacketCodec<RegistryByteBuf,HudPacket> CODEC=PacketCodec.of((p,b)->b.writeString(p.lines,1024),b->new HudPacket(b.readString(1024)));
 public Id<? extends CustomPayload> getId(){return ID;}
}
