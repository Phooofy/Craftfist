package dev.craftfist;

/** Minecraft-independent movement math, measured in blocks per tick. */
public final class Motion {
 private Motion() {}
 public static boolean hasIncomingMomentum(double x,double y,double z){return Math.hypot(x,z)>.04||Math.abs(y)>.12;}
 public static double punchVertical(double incoming,double aimed){return Math.max(incoming,aimed);}
 public static boolean inSlamCone(double forwardX,double forwardZ,double offsetX,double offsetZ){
  double distance=Math.hypot(offsetX,offsetZ),length=Math.hypot(forwardX,forwardZ);
  if(distance>7+1e-9)return false;
  if(distance<1e-6)return true;
  if(length<1e-6)return false;
  return (forwardX*offsetX+forwardZ*offsetZ)/(length*distance)>=Math.cos(Math.toRadians(35))-1e-9;
 }
 /** Thirty-degree total horizontal cone, centered on the punch launch direction. */
 public static boolean inPunchCone(double forwardX,double forwardZ,double offsetX,double offsetZ){
  double forwardLength=Math.hypot(forwardX,forwardZ),offsetLength=Math.hypot(offsetX,offsetZ);
  if(offsetLength<1e-6)return true;
  if(forwardLength<1e-6)return false;
  return (forwardX*offsetX+forwardZ*offsetZ)/(forwardLength*offsetLength)>=Math.cos(Math.toRadians(15))-1e-9;
 }
 public static double punchSpeed(int charge, boolean empowered) {
  return (.65 + Math.clamp(charge, 0, 30) / 30.0 * 1.75) * (empowered ? 1.35 : 1);
 }
 public static double slamHorizontal(double incoming, double direction) {
  return incoming * .95 + direction * 1.65;
 }
 public static double slamVertical(double incoming, double lookY) {
  return Math.max(incoming, .9) + Math.max(0, lookY) * .5;
 }
}
