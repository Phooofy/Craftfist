package dev.craftfist;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
public record PunchStatePacket(int charge,int dash,int block,int uppercut) implements CustomPayload {
 public static final Id<PunchStatePacket> ID=new Id<>(Identifier.of("craftfist","punch_state"));
 public static final PacketCodec<RegistryByteBuf,PunchStatePacket> CODEC=PacketCodec.of((p,b)->{b.writeVarInt(p.charge);b.writeVarInt(p.dash);b.writeVarInt(p.block);b.writeVarInt(p.uppercut);},b->new PunchStatePacket(b.readVarInt(),b.readVarInt(),b.readVarInt(),b.readVarInt()));
 public Id<? extends CustomPayload> getId(){return ID;}
}
