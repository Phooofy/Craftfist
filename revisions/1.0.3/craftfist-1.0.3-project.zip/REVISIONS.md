# Craftfist revisions

Each completed change gets a new patch version: 1.0.1, 1.0.2, 1.0.3, and so on. The single version setting is `mod_version` in `gradle.properties`; Gradle embeds it into the mod metadata and JAR filename.

Successful builds archive the installable JAR, complete project source ZIP, and SHA-256 checksums under `revisions/<version>/`. Existing archives cannot be replaced with different contents; the build requires a new version number. Keep this directory to preserve rollback history.

| Version | Change |
| --- | --- |
| 1.0.0 | Preserved baseline: latest momentum-preserving charge implementation, prior to revision numbering. Includes the current slab and wall-sliding fixes. Earlier builds repeatedly used this filename and are not recoverable from this project. |
| 1.0.1 | Revision numbering, embedded version metadata, automatic immutable build archives, and rollback instructions. Gameplay matches the 1.0.0 baseline. |
| 1.0.2 | Punch charging always slows new ground movement input to 35%, including when activated while walking. Existing velocity is not damped by the charge; airborne momentum and normal gravity/friction remain intact. |
| 1.0.3 | Full-precision velocity synchronization for fast combos; directional wall-impact checks; empowerment consumed on launch; menus cancel punch charge; Power Block retains damage attribution; Slam stays armed through long falls; Meteor steering ignores camera pitch; cooldowns continue while unequipped. |

## Restore a revision

Ask for a version by number, for example: “Go back to 1.0.1.” To restore the installed mod, close Minecraft, remove the current Craftfist JAR from `mods/`, and install `revisions/1.0.1/craftfist-1.0.1.jar`. Keep only one Craftfist JAR installed. Back up your world before switching versions that change saved data.

For development rollback, extract the archived project ZIP into a separate folder and use its source. Preserve the main project's `revisions/` directory. A later modified build must receive a new version rather than overwrite the restored archive.
