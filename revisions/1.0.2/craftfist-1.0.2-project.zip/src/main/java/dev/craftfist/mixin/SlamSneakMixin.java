package dev.craftfist.mixin;
import dev.craftfist.Craftfist;
import dev.craftfist.PunchAnimation;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.client.input.Input;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(KeyboardInput.class)
public class SlamSneakMixin {
 @Inject(method="tick",at=@At("TAIL"))
 private void craftfist$abilityMovement(boolean slowDown,float slowFactor,CallbackInfo ci){
  MinecraftClient c=MinecraftClient.getInstance();
  if(c.player!=null && Craftfist.equipped(c.player)){
   Input input=(Input)(Object)this;
   boolean wasSneaking=input.sneaking;
   input.sneaking=false;
   if(wasSneaking && slowDown && slowFactor>0){input.movementForward/=slowFactor;input.movementSideways/=slowFactor;}
   // Slow ground input during every charge without damping carried velocity or airborne momentum.
   if(PunchAnimation.shouldSlowCharge() && c.player.isOnGround()){input.movementForward*=.35f;input.movementSideways*=.35f;}
  }
 }
}
