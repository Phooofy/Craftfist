package dev.craftfist;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
public class CraftfistClient implements ClientModInitializer {
 private final KeyBinding punch=key("punch",GLFW.GLFW_KEY_R),slam=key("slam",GLFW.GLFW_KEY_LEFT_SHIFT),upper=key("uppercut",GLFW.GLFW_KEY_X),block=key("block",GLFW.GLFW_KEY_V),meteor=key("meteor",GLFW.GLFW_KEY_Z);
 private static String hud="";
 private boolean punching,jumping,slamming;
 private static KeyBinding key(String name,int code){return KeyBindingHelper.registerKeyBinding(new KeyBinding("key.craftfist."+name,InputUtil.Type.KEYSYM,code,"category.craftfist"));}
 private static void send(int a){if(ClientPlayNetworking.canSend(AbilityPacket.ID))ClientPlayNetworking.send(new AbilityPacket(a));}
 public void onInitializeClient(){
  ClientPlayNetworking.registerGlobalReceiver(HudPacket.ID,(packet,context)->context.client().execute(()->hud=packet.lines()));
  HudRenderCallback.EVENT.register((draw,ticks)->{
   MinecraftClient client=MinecraftClient.getInstance();
   if(client.player==null||client.options.hudHidden||!Craftfist.equipped(client.player)||hud.isEmpty())return;
   String[] lines=hud.split("\n");int y=10,width=0;
   for(String line:lines)width=Math.max(width,client.textRenderer.getWidth(line));
   draw.fill(6,6,18+width,14+lines.length*12,0xA0202028);
   for(String line:lines){draw.drawTextWithShadow(client.textRenderer,line,10,y,line.contains("READY")?0xFF80FFB0:0xFFFFD56A);y+=12;}
  });
  ClientPlayNetworking.registerGlobalReceiver(PunchStatePacket.ID,(packet,context)->context.client().execute(()->PunchAnimation.receive(packet.charge(),packet.dash(),packet.block(),packet.uppercut())));
  ClientTickEvents.END_CLIENT_TICK.register(c->{
  PunchAnimation.tick(c.player!=null && Craftfist.equipped(c.player));
  if(c.player==null)hud="";
  if(c.player==null||c.currentScreen!=null||!Craftfist.equipped(c.player)){if(punching)send(1);punching=jumping=slamming=false;return;}
  boolean p=c.options.useKey.isPressed()||punch.isPressed(),j=c.options.jumpKey.isPressed();
  boolean s=slam.isPressed()||(slam.matchesKey(GLFW.GLFW_KEY_LEFT_SHIFT,0)&&InputUtil.isKeyPressed(c.getWindow().getHandle(),GLFW.GLFW_KEY_LEFT_SHIFT));
  if(p&&!punching)send(0);if(!p&&punching)send(1);
  while(block.wasPressed())send(4);
  if(s&&!slamming)send(2);while(slam.wasPressed()){}while(upper.wasPressed())send(3);while(meteor.wasPressed())send(6);
  if(c.options.attackKey.isPressed())send(7);if(j&&!jumping)send(8);
  punching=p;jumping=j;slamming=s;
 });}
}
