# Craftfist

A Doomfist-inspired mod for **Minecraft Java 1.21.1 / Fabric**, combining Rising Uppercut with Power Block. Install Fabric Loader 0.16.14 or newer, Fabric API for 1.21.1, and the Craftfist JAR in `mods/`. Multiplayer requires the mod and Fabric API on both server and clients. Java 21 is required.

## Become Doomfist

Craft the gauntlet and hold it in either hand. Your player skin becomes the supplied Thunder Doomfist skin; putting the gauntlet away restores your usual appearance. Holding it in the offhand allows other items in your main hand, but left click still fires Hand Cannon.

Recipe (`I` iron block, `N` netherite ingot, `R` redstone block, `D` diamond):

```
I N I
R D R
  I I
```

Creative / commands: `/give @s craftfist:gauntlet`.

## Controls

All ability keys can be changed in Minecraft's Controls menu under Craftfist.

| Input | Ability |
| --- | --- |
| Left click | Hand Cannon: seven hitscan pellets, four rounds, automatic reload |
| Hold right click, release (or R) | Rocket Punch: full charge at 1.5 seconds; holds until released. Forward dash and knockback within a 30-degree frontal cone (15 degrees each side). |
| Left Shift | Seismic Slam: longer horizontal leap and impact damage on landing |
| X | Rising Uppercut: launch yourself and nearby entities into the air |
| V, press again to cancel | Power Block: three-second guard; reduce frontal damage by 80%; absorbing 8 damage empowers punch |
| Z | Meteor Strike at 100% ultimate; press again after 0.5 seconds to land early |
| Space during punch | Jump cancel, preserving horizontal momentum |

The top-left corner shows ammo, cooldowns, ultimate charge, and empowerment. Ability hits grant temporary absorption (up to eight hearts). Ultimate charges passively and from damage. Meteor Strike rises about 25 blocks when unobstructed, grants immunity while airborne, and lands beneath your current position; aim horizontally to reposition.

Right click is reserved for Rocket Punch while the gauntlet is equipped, including in the offhand. Put it away to use blocks or other items. The held item mesh is hidden in first and third person. The textured fist floats in view during charging, extends during the dash, and recovers afterward. Power Block moves the arm inward across the face. Poses follow the server's accepted ability state. Sneaking is suppressed while transformed so Left Shift can launch Slam without slowing movement.

## Movement tech

Charging punch slows new ground movement input to 35% regardless of whether you were already walking. It does not multiply or reset your existing velocity, so momentum from Slam, Uppercut, or knockback continues under normal Minecraft physics. Airborne steering does not receive the ground-input slowdown.

Hold right click while aiming horizontally, then press Left Shift before releasing. Stored punch charge becomes additional slam launch velocity. You can also release punch and press Left Shift during the dash. Uppercut preserves horizontal velocity; Rocket Punch preserves incoming upward momentum and applies gravity during travel. Space cancels an active punch with a small upward and horizontal boost. The first entity in the punch path stops the dash and is knocked away. A target knocked into a wall takes an additional eight damage, bypassing the initial hit's immunity window, and is briefly slowed.

Existing Minecraft controls may retain older custom bindings. Set Seismic Slam to Left Shift and Rising Uppercut to X in Controls if your options file still has F/G.

## Sound effects

Each ability has a named sound event in `assets/craftfist/sounds.json`, including charge, release, entity hit, wall hit, slam launch/impact, uppercut, block start/hit, empowerment, Meteor Strike ascent/impact, and Hand Cannon. The bundled effects are Minecraft placeholders, not original Overwatch recordings. They can be replaced with a resource pack containing mono OGG audio.

Research found [Doomfist voice archives](https://sounds.spriters-resource.com/pc_computer/overwatch/asset/405743/) and an [OW1 ability effects recording](https://www.youtube.com/watch?v=kVEQ5IKfjLc), but did not establish a complete, verified set of isolated OW1 and OW2 ability effects. No audio was extracted from trailers or mislabeled as original audio.

This is a Minecraft adaptation, with Minecraft-scale damage and cooldowns. It does not reproduce every Overwatch map collision exploit or use Overwatch animations, voices, or models. The provided skin uses the standard wide Minecraft player model.

## Build

With JDK 21 installed, run `./gradlew build` (Windows: `gradlew.bat build`). The installable JAR is `build/libs/craftfist-<version>.jar`; do not install the sources JAR. Each build preserves its JAR and complete source archive under `revisions/<version>/`. See [revision history and rollback instructions](REVISIONS.md). Development client: `gradlew.bat runClient`.

## Playtest checklist

- Craft and equip in either hand; check the skin in third person and first-person arm.
- Compare short and fully charged punch distance and damage; punch a mob toward a wall.
- Hold R, press F, and compare travel with an uncharged slam. Try dash → Space and dash → F.
- Uppercut a mob, then chain slam; confirm fall protection expires.
- Block a frontal attack, then attack from behind; only the frontal attack should be reduced.
- Empower punch with frontal damage, then use it within ten seconds.
- Fire four shots, wait for reload, and test that blocks stop pellets.
- Charge Meteor Strike, reposition, and land on mobs; check early landing and ceiling behavior.
- Repeat with two clients on a dedicated server, including death, disconnect, and item removal.

The supplied character texture and Doomfist/Overwatch names belong to their respective owners; this is an unofficial fan mod.
