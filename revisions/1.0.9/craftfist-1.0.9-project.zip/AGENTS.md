# Revision workflow

For each completed user-requested mod revision, increment the patch number in `gradle.properties` (`mod_version`) once and add a concise entry to `REVISIONS.md`. Related follow-up edits completed before delivering that revision use the same version. Fix build failures before archiving.

Run `gradlew.bat build` to compile, test, and automatically archive the revision's JAR and full project source ZIP. Never delete or modify existing files under `revisions/` to make an archive check pass. Existing versions are immutable. Link the numbered archived JAR when delivering a revision.

If the user requests a rollback, use the matching archive. Preserve all revision archives. For later edits based on an older revision, assign a new unused version greater than the highest archived version.
