# Craftfist

A Doomfist-inspired mod for **Minecraft Java 1.21.1 / Fabric**, combining Rising Uppercut with Power Block. Install Fabric Loader 0.16.14 or newer, Fabric API for 1.21.1, and the Craftfist JAR in `mods/`. Multiplayer requires the mod and Fabric API on both server and clients. Java 21 is required.

## Become Doomfist

Craft the gauntlet and hold it in either hand. Your player skin becomes the supplied Thunder Doomfist skin; putting the gauntlet away restores your usual appearance. Holding it in the offhand allows other items in your main hand, but left click still fires Hand Cannon.

Recipe (`I` iron block, `N` netherite ingot, `R` redstone block, `D` diamond):

```
I N I
R D R
  I I
```

Creative / commands: `/give @s craftfist:gauntlet`.

## Controls

All ability keys can be changed in Minecraft's Controls menu under Craftfist.

| Input | Ability |
| --- | --- |
| Left click | Hand Cannon: seven hitscan pellets per shot, four rounds; ammo starts regenerating after one second without firing |
| Hold right click, release (or R) | Rocket Punch: full charge at 1.5 seconds; holds until released. Forward dash and knockback within a 30-degree frontal cone (15 degrees each side). |
| Left Shift | Seismic Slam: longer horizontal leap and landing damage in a seven-block, 90-degree cone |
| X | Rising Uppercut: launch yourself and nearby entities into the air |
| V, press again to cancel | Power Block: three-second guard; reduce frontal damage by 80%; absorbing 8 damage empowers punch |
| Z | Meteor Strike at 100% ultimate; press again after 0.5 seconds to land early |
| Space during punch | Jump cancel, preserving horizontal momentum |

The top-left corner shows ammo, cooldowns, ultimate charge, and empowerment. Ability hits grant temporary absorption (up to eight hearts). Ultimate charges passively and from damage. Meteor Strike rises about 25 blocks when unobstructed and grants immunity while airborne. Turn to steer; looking up or down does not change its horizontal speed. When its timer ends or you press Z again, it drops straight down at six blocks per tick using normal terrain collision. Landing triggers damage in all directions and an expanding 360-degree ground particle wave out to eight blocks. Water and lava also trigger the impact; a descent into the void cancels without an airborne explosion. Cooldowns continue counting down while the gauntlet is put away.

Right click is reserved for Rocket Punch while the gauntlet is equipped, including in the offhand. Put it away to use blocks or other items. The held item mesh is hidden in first and third person. The textured fist floats in view during charging, extends during the dash, and recovers afterward. Power Block moves the arm inward across the face. Poses follow the server's accepted ability state. Sneaking is suppressed while transformed so Left Shift can launch Slam without slowing movement.

## Movement tech

The left-corner HUD uses a distinct pixel icon for each ability, four ammo pips, ready/cooldown colors, progress bars, and badges showing current keybinds. It scales down to fit small windows. Hand Cannon's first replacement round arrives after 20 ticks without firing; subsequent rounds regenerate every 13 ticks. Any accepted shot restarts that full one-second wait.

Charging punch slows ground and air steering to 35%, including while jumping. Ordinary incoming horizontal movement is slowed once when charging begins; ordinary speed is then bounded without repeatedly damping velocity, and sprinting is disabled. Momentum from Slam, Uppercut, Rocket Punch, or its jump cancel is tagged and preserved under normal Minecraft physics until landing or cancellation; new steering remains slowed. Walking, sprint-jumping, and ordinary knockback do not grant this exemption.

Slam's horizontal launch speed is tuned to travel approximately three blocks farther than 1.0.3 on flat ground with a level view. Terrain, existing momentum, and aim change the final distance. Landing damage and particles share a seven-block, 90-degree cone.

Hold right click while aiming horizontally, then press Left Shift before releasing. Stored punch charge becomes additional slam launch velocity. You can also release punch and press Left Shift during the dash. Uppercut preserves horizontal velocity; Rocket Punch preserves incoming upward momentum and applies gravity during travel. Space cancels an active punch with a small upward and horizontal boost. The first entity in the punch path stops the dash and is knocked away. A target knocked into a wall takes an additional eight damage, bypassing the initial hit's immunity window, and is briefly slowed.

Fast combos use full-precision velocity updates so client and server retain the same speed. Empowerment is spent when the punch launches or its stored charge is converted into Slam momentum. Opening a menu cancels a charging punch without firing it. Slam stays armed through long falls and other ability chains until landing; water, lava, flight, riding, Meteor Strike, death, or putting away the gauntlet cancel it. Power Block preserves the original attacker and damage type when reducing damage.

Existing Minecraft controls may retain older custom bindings. Set Seismic Slam to Left Shift and Rising Uppercut to X in Controls if your options file still has F/G.

## Sound effects

Each ability has a named sound event in `assets/craftfist/sounds.json`, including charge, release, entity hit, wall hit, slam launch/impact, uppercut, block start/hit, empowerment, Meteor Strike ascent/impact, and Hand Cannon. The bundled effects are Minecraft placeholders, not original Overwatch recordings. They can be replaced with a resource pack containing mono OGG audio.

Research found [Doomfist voice archives](https://sounds.spriters-resource.com/pc_computer/overwatch/asset/405743/) and an [OW1 ability effects recording](https://www.youtube.com/watch?v=kVEQ5IKfjLc), but did not establish a complete, verified set of isolated OW1 and OW2 ability effects. No audio was extracted from trailers or mislabeled as original audio.

This is a Minecraft adaptation, with Minecraft-scale damage and cooldowns. It does not reproduce every Overwatch map collision exploit or use Overwatch animations, voices, or models. The provided skin uses the standard wide Minecraft player model.

## Build

With JDK 21 installed, run `./gradlew build` (Windows: `gradlew.bat build`). The installable JAR is `build/libs/craftfist-<version>.jar`; do not install the sources JAR. Each build preserves its JAR and complete source archive under `revisions/<version>/`. See [revision history and rollback instructions](REVISIONS.md). Development client: `gradlew.bat runClient`.

## Playtest checklist

- Craft and equip in either hand; check the skin in third person and first-person arm.
- Compare short and fully charged punch distance and damage; punch a mob toward a wall.
- Hold R, press Left Shift, and compare travel with an uncharged slam. Try dash → Space and dash → Left Shift.
- Uppercut a mob, then chain slam; confirm fall protection expires.
- Block a frontal attack, then attack from behind; only the frontal attack should be reduced.
- Empower punch with frontal damage, then use it within ten seconds.
- Fire four shots, wait for reload, and test that blocks stop pellets.
- Charge Meteor Strike, reposition, and land on mobs; check early landing and ceiling behavior.
- Trigger Meteor Strike above a platform, then press Z again; confirm a visible rapid descent, collision with the first surface, one landing impact, and a circular ground wave in every direction. Repeat over water and over a void with no landing surface.
- Repeat with two clients on a dedicated server, including death, disconnect, and item removal.
- Use an empowered punch-to-slam at full charge; check that fast movement stays consistent on a dedicated server.
- Punch along a wall, away from a wall, and directly into a wall; bonus damage should require an impact opposing knockback.
- Launch an empowered punch, jump-cancel it, and wait for another punch; empowerment should have been spent.
- Open inventory while charging; the charge should cancel without a dash.
- Slam from a high ledge and confirm a single landing impact even after more than 2.5 seconds airborne.
- Look straight down during Meteor Strike and compare horizontal speed with a level view.
- Use an ability, put away the gauntlet for several seconds, and confirm its cooldown elapsed.
- Charge while walking or sprint-jumping; check that horizontal travel and steering slow in both ground and air. Compare against Slam/Uppercut into charge, which should retain ability momentum until landing.
- Compare a level, stationary Slam against 1.0.3 on flat ground; expect about three more blocks of travel and a wider 90-degree particle fan.

The supplied character texture and Doomfist/Overwatch names belong to their respective owners; this is an unofficial fan mod.
